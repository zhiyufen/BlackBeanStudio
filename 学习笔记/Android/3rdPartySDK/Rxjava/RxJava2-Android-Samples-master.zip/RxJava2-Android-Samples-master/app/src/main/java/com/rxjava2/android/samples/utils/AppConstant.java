package com.rxjava2.android.samples.utils;

/**
 * Created by amitshekhar on 30/08/16.
 */
public final class AppConstant {

    private AppConstant() {
        // This class in not publicly instantiable.
    }

    public static final String LINE_SEPARATOR = "\n";

}
